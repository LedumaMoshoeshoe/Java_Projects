package counterapp;

import java.util.concurrent.atomic.AtomicInteger;

public class Counter {
    private int synchronizedCounter = 0;
    private AtomicInteger atomicCounter = new AtomicInteger(0);

    // Synchronized increment method
    public synchronized void incrementSynchronizedCounter() {
        synchronizedCounter++;
    }

    // Atomic increment method
    public void incrementAtomicCounter() {
        atomicCounter.incrementAndGet();
    }

    // Getters for the counters
    public int getSynchronizedCounter() {
        return synchronizedCounter;
    }

    public int getAtomicCounter() {
        return atomicCounter.get();
    }
}
