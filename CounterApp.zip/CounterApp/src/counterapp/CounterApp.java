package counterapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CounterApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

    private static void createAndShowGUI() {
        // Create an instance of the Counter class
        Counter counter = new Counter();

        JFrame frame = new JFrame("Counter App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2)); // Use a grid layout for components

        JLabel enterValueLabel = new JLabel("Enter Value:");
        JTextField valueTextField = new JTextField(10);

        JLabel resultLabel = new JLabel("Result:");
        JTextField resultTextField = new JTextField(10);
        resultTextField.setEditable(false); // Make the result field read-only

        JButton countButton = new JButton("Count");

        countButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int numIncrements = Integer.parseInt(valueTextField.getText());
                    Thread thread1 = new Thread(new CounterThread(counter, numIncrements));
                    Thread thread2 = new Thread(new CounterThread(counter, numIncrements));
                    thread1.start();
                    thread2.start();
                    try {
                        thread1.join();
                        thread2.join();
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }

                    // Update the result text field with the final counter value
                    resultTextField.setText(Integer.toString(counter.getCounterValue()));
                } catch (NumberFormatException ex) {
                    // Handle invalid input gracefully
                    resultTextField.setText("Invalid input");
                }
            }
        });

        // Add components to the panel
        panel.add(enterValueLabel);
        panel.add(valueTextField);
        panel.add(resultLabel);
        panel.add(resultTextField);
        panel.add(countButton);

        frame.add(panel);
        frame.setVisible(true);
    }
}

class Counter {
    private int counter = 0;

    public synchronized void increment() {
        counter++;
    }

    public synchronized int getCounterValue() {
        return counter;
    }
}

class CounterThread implements Runnable {
    private Counter counter;
    private int numIncrements;

    public CounterThread(Counter counter, int numIncrements) {
        this.counter = counter;
        this.numIncrements = numIncrements;
    }

    @Override
    public void run() {
        for (int i = 0; i < numIncrements; i++) {
            counter.increment();
        }
    }
}
