package counterapp;

public class CounterThread implements Runnable {
    private Counter counter;

    public CounterThread(Counter counter) {
        this.counter = counter;
    }

    @Override
    public void run() {
        // Increment the counter 1000 times
        for (int i = 0; i < 1000; i++) {
            counter.incrementSynchronizedCounter(); // or counter.incrementAtomicCounter();
        }
    }
}

