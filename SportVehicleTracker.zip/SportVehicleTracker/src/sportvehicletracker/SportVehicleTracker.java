package sportvehicletracker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class SportVehicleTracker extends JFrame {
    private JLabel selectLabel;
    private JRadioButton audiRadio, jaguarRadio, porscheRadio;
    private JButton submitButton;
    private JList<String> vehicleList;

    private HashMap<String, String> vehicleDetailsMap; // Store the loaded vehicle details

    public SportVehicleTracker() {
        // Set the window title
        setTitle("Sport Vehicle Tracker");

        // Create and set layout manager
        setLayout(new FlowLayout());

        // Initialize components
        selectLabel = new JLabel("Select Vehicle:");
        audiRadio = new JRadioButton("Audi TT");
        jaguarRadio = new JRadioButton("Jaguar F-Type");
        porscheRadio = new JRadioButton("Porsche");
        submitButton = new JButton("Submit");
        vehicleList = new JList<>();

        // Create a ButtonGroup for radio buttons to ensure only one can be selected at a time
        ButtonGroup vehicleGroup = new ButtonGroup();
        vehicleGroup.add(audiRadio);
        vehicleGroup.add(jaguarRadio);
        vehicleGroup.add(porscheRadio);

        // Add components to the frame
        add(selectLabel);
        add(audiRadio);
        add(jaguarRadio);
        add(porscheRadio);
        add(submitButton);
        add(new JScrollPane(vehicleList)); // Add a scroll pane for the list

        // Register an ActionListener for the submit button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implement what happens when the submit button is clicked
                displayVehicleDetails();
            }
        });

        // Set frame properties
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setVisible(true);

        // Load vehicle data at the beginning
        loadVehicleData();
    }

    // Method to load data from cars.txt and populate the list
    private void loadVehicleData() {
        vehicleDetailsMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader("\"C:\\Users\\OEM\\OneDrive - CTU Career\\Documents\\NetBeansProjects\\SportVehicleTracker\\src\\sportvehicletracker\\cars.txt\""))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Split the line into fields using a delimiter (e.g., comma)
                String[] fields = line.split(",");
                String vehicleName = fields[0];
                String vehicleSpecifications = "Price: R" + fields[1] + ", 0-100: " + fields[2] + " seconds, Engine: " + fields[3] + " litre";

                // Store the vehicle details in the map with the vehicle name as the key
                vehicleDetailsMap.put(vehicleName, vehicleSpecifications);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set the list model with vehicle names
        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (String vehicleName : vehicleDetailsMap.keySet()) {
            listModel.addElement(vehicleName);
        }
        vehicleList.setModel(listModel);
    }

    // Method to display selected vehicle details
    private void displayVehicleDetails() {
        String selectedVehicle = vehicleList.getSelectedValue();
        if (selectedVehicle != null) {
            String vehicleSpecifications = vehicleDetailsMap.get(selectedVehicle);
            if (vehicleSpecifications != null) {
                JOptionPane.showMessageDialog(this, "Selected Vehicle Details:\n" + selectedVehicle + "\n" + vehicleSpecifications);
            } else {
                JOptionPane.showMessageDialog(this, "Vehicle specifications not found for " + selectedVehicle);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a vehicle from the list.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SportVehicleTracker();
        });
    }
}
