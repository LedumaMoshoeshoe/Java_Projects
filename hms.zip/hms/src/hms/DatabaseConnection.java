package hms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    public static Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/hmsdb?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String username = "hmsdb";
        String password = "Ledumam@12";
        Connection connection = DriverManager.getConnection(url, username, password);
        return connection;
    }
}
