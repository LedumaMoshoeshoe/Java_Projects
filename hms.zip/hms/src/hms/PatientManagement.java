package hms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PatientManagement {
    public static void main(String[] args) {
        JFrame patientFrame = new JFrame("Patient Management");
        patientFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        patientFrame.setSize(400, 200);
        
        JPanel panel = new JPanel();
        JLabel firstNameLabel = new JLabel("First Name:");
        JLabel lastNameLabel = new JLabel("Last Name:");
        JLabel dobLabel = new JLabel("Date of Birth:");
        JLabel conditionLabel = new JLabel("Medical Condition:");
        JTextField firstNameField = new JTextField(20);
        JTextField lastNameField = new JTextField(20);
        JTextField dobField = new JTextField(20);
        JTextField conditionField = new JTextField(20);
        JButton addButton = new JButton("Add Patient");
        JTextArea patientList = new JTextArea(10, 20);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String dob = dobField.getText();
                String condition = conditionField.getText();
                if (addPatient(firstName, lastName, dob, condition)) {
                    patientList.append(firstName + " " + lastName + "\n");
                    firstNameField.setText("");
                    lastNameField.setText("");
                    dobField.setText("");
                    conditionField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to add the patient.");
                }
            }
        });

        panel.add(firstNameLabel);
        panel.add(firstNameField);
        panel.add(lastNameLabel);
        panel.add(lastNameField);
        panel.add(dobLabel);
        panel.add(dobField);
        panel.add(conditionLabel);
        panel.add(conditionField);
        panel.add(addButton);
        panel.add(patientList);

        patientFrame.add(panel);
        patientFrame.setVisible(true);
    }

    private static boolean addPatient(String firstName, String lastName, String dob, String condition) {
        String query = "INSERT INTO patients (first_name, last_name, dob, medical_condition) VALUES (?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, dob);
            preparedStatement.setString(4, condition);
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
