package hms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegistrationFrame {
    public static void main(String[] args) {
        JFrame registrationFrame = new JFrame("Registration");
        registrationFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        registrationFrame.setSize(400, 200);
        
        JPanel panel = new JPanel();
        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");
        JLabel nameLabel = new JLabel("Name:");
        JTextField userField = new JTextField(20);
        JPasswordField passField = new JPasswordField(20);
        JTextField nameField = new JTextField(20);
        JButton registerButton = new JButton("Register");

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passField.getPassword());
                String name = nameField.getText();
                if (registerUser(username, password, name)) {
                    JOptionPane.showMessageDialog(null, "Registration successful.");
                } else {
                    JOptionPane.showMessageDialog(null, "Registration failed.");
                }
            }
        });

        panel.add(userLabel);
        panel.add(userField);
        panel.add(passLabel);
        panel.add(passField);
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(registerButton);

        registrationFrame.add(panel);
        registrationFrame.setVisible(true);
    }

    private static boolean registerUser(String username, String password, String name) {
        String query = "INSERT INTO users (username, password, name) VALUES (?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, name);
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
