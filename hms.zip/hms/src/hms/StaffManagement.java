package hms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StaffManagement {
    public static void main(String[] args) {
        JFrame staffFrame = new JFrame("Staff Management");
        staffFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        staffFrame.setSize(400, 200);
        
        JPanel panel = new JPanel();
        JLabel firstNameLabel = new JLabel("First Name:");
        JLabel lastNameLabel = new JLabel("Last Name:");
        JLabel roleLabel = new JLabel("Role:");
        JTextField firstNameField = new JTextField(20);
        JTextField lastNameField = new JTextField(20);
        JTextField roleField = new JTextField(20);
        JButton addButton = new JButton("Add Staff");
        JTextArea staffList = new JTextArea(10, 20);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String role = roleField.getText();
                if (addStaff(firstName, lastName, role)) {
                    staffList.append(firstName + " " + lastName + " - " + role + "\n");
                    firstNameField.setText("");
                    lastNameField.setText("");
                    roleField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to add the staff member.");
                }
            }
        });

        panel.add(firstNameLabel);
        panel.add(firstNameField);
        panel.add(lastNameLabel);
        panel.add(lastNameField);
        panel.add(roleLabel);
        panel.add(roleField);
        panel.add(addButton);
        panel.add(staffList);

        staffFrame.add(panel);
        staffFrame.setVisible(true);
    }

    private static boolean addStaff(String firstName, String lastName, String role) {
        String query = "INSERT INTO staff (first_name, last_name, role) VALUES (?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, role);
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
